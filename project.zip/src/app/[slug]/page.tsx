import { notFound } from "next/navigation";
import { BarChart3, CheckCircle2, HeartHandshake, PenTool, Store, WandSparkles } from "lucide-react";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const valid = ["services", "about", "faq", "terms", "privacy", "refund-policy"];
export const dynamic = "force-dynamic";

export default async function PublicPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (!valid.includes(slug)) notFound();
  const currentUser = await getCurrentUser();
  let body: React.ReactNode;
  if (slug === "services") {
    const services = await prisma.service.findMany({ where: { status: "ACTIVE" }, orderBy: { displayOrder: "asc" } });
    body = <><Heading eyebrow="Services" title="The content capabilities your business needs." text="Choose a package or individual service as your content operation grows."/><div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">{services.length ? services.map((service, index) => { const Icon = [PenTool, BarChart3, WandSparkles][index % 3]; return <article key={service.id} className="rounded-3xl border bg-white p-7 shadow-sm"><div className="grid h-12 w-12 place-items-center rounded-2xl bg-blue-50 text-primary"><Icon/></div><h2 className="mt-5 text-xl font-bold">{service.name}</h2><p className="mt-3 leading-7 text-slate-600">{service.description}</p><span className="mt-5 inline-block rounded-full bg-slate-100 px-3 py-1 text-xs font-bold">{service.category}</span></article>; }) : <Empty/>}</div></>;
  } else if (slug === "faq") {
    const faqs = await prisma.fAQ.findMany({ where: { status: "ACTIVE" }, orderBy: { displayOrder: "asc" } });
    body = <><Heading eyebrow="FAQ" title="Answers before you get started." text="Everything you need to know about working with Nexora."/><Accordion type="single" collapsible className="mx-auto mt-10 max-w-3xl rounded-3xl border bg-white px-6">{faqs.length ? faqs.map(faq => <AccordionItem key={faq.id} value={faq.id}><AccordionTrigger className="text-left font-bold">{faq.questionEn}</AccordionTrigger><AccordionContent className="leading-7 text-slate-600">{faq.answerEn}</AccordionContent></AccordionItem>) : <Empty/>}</Accordion></>;
  } else if (slug === "about") {
    body = <><Heading eyebrow="About Nexora" title="Local insight. Modern content systems." text="Nexora was designed around the reality of local businesses: small teams, ambitious goals, and no time for an inconsistent content process."/><div className="mt-12 grid gap-5 md:grid-cols-3">{[[Store, "Built for local business", "Workflows shaped around restaurants, cafes, shops, salons, and digital stores."], [HeartHandshake, "Human where it matters", "AI helps us move faster; thoughtful people protect quality, context, and brand voice."], [CheckCircle2, "Clarity by default", "Every request, payment, status, and delivery remains visible in one workspace."]].map(([Icon, title, text]) => <article key={String(title)} className="rounded-3xl border bg-white p-7"><Icon className="text-primary"/><h2 className="mt-5 text-xl font-bold">{String(title)}</h2><p className="mt-3 leading-7 text-slate-600">{String(text)}</p></article>)}</div></>;
  } else {
    const key = slug === "refund-policy" ? "refund_policy" : slug;
    const section = await prisma.websiteSection.findUnique({ where: { key } });
    const title = slug === "terms" ? "Terms of service" : slug === "privacy" ? "Privacy policy" : "Refund policy";
    body = <><Heading eyebrow="Legal" title={section?.titleEn ?? title} text="Please review the policy below."/><article className="prose prose-slate mx-auto mt-10 max-w-3xl rounded-3xl border bg-white p-8 leading-8 text-slate-600"><p>{typeof section?.contentEn === "string" ? section.contentEn : "This policy is being prepared. Contact Nexora for the current applicable terms."}</p></article></>;
  }
  return <main className="min-h-screen bg-[#fcfbf8]"><SiteHeader user={currentUser ? { name: currentUser.name, role: currentUser.role.name } : null}/><section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">{body}</section><SiteFooter/></main>;
}

function Heading({ eyebrow, title, text }: { eyebrow: string; title: string; text: string }) { return <div className="mx-auto max-w-3xl text-center"><p className="text-sm font-bold uppercase tracking-[.18em] text-primary">{eyebrow}</p><h1 className="mt-3 text-4xl font-extrabold tracking-tight sm:text-5xl">{title}</h1><p className="mt-5 text-lg leading-8 text-slate-600">{text}</p></div>; }
function Empty() { return <div className="col-span-full rounded-3xl border border-dashed bg-white p-12 text-center"><p className="font-bold">No data available</p><p className="mt-2 text-sm text-slate-500">Published content will appear here.</p></div>; }
